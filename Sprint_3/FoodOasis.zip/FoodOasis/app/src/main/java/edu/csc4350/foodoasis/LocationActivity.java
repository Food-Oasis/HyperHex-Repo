package edu.csc4350.foodoasis;

public class LocationActivity {
}
