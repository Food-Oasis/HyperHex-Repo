package edu.csc4350.foodoasis;

public class Location {
    //Base class to hold information about the location

        //Location basics


        //constructor


        //getters


    }

